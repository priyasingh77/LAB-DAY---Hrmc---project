package com.HRMS;

public class Employee {
	int eid, esal;
	String ename, ephone,elocation,edesignation;

}
