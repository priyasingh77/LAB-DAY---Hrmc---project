package com.HRMS;

import java.util.Scanner;

public class HRMSmain {

	public static void main(String[] args)  throws Exception{
		Scanner sc =new Scanner (System .in );     //Scanner object created
		HRMSdao hrd =new HRMSdao();
		hrd.connect();

		Employee emp =new Employee();
		System.out.println("**** Welcome to Human resource managemet system  ****");
		
		System.out.println(" Press 1 : add Employee \n Press 2 : increase Salary of the Employee \n Press 3 : Remove an Employee \n ");
		int choose = sc.nextInt();
		
		switch (choose) {
		//using switch for choosing   cases
		case 1 -> {		
			//New employee details adding here.
			System.out.println("Enter the details of New wmployee");
			System.out.println("Enter  Employee Name :");
		    emp.ename = sc.next();
			System.out.println("Enter Phone number :");
			emp.ephone = sc.next();
			System.out.println("Enter Salary :");
			emp.esal = sc.nextInt();
			System.out.println("Enter location :");
			emp.elocation = sc.next();
			System.out.println("Enter  Designation :");
			emp.edesignation = sc.next();
			
			
			
			int var1 = hrd.newEmployee(emp);   //calling newEmployee methods
			if (var1 == 1)
				System.out.println("Employee added Successfully.");
			//Checking if employee already exist in the company.
			else
				System.out.println("Employee already exist");
	        }
		case 2 ->{
			int amount ,id;
			//Employee id as input.
			System.out.print("Enter Employee Id:");
			id = sc.nextInt();	
			
			System.out.print("Enter percentage(%)  to increment salary:");
			amount = sc.nextInt();	
			
			int var3 = hrd.increasesal(id, amount);     //increaseSalary method is called here. 
			
			if (var3==1)
				System .out.println("salary is increased");
			
			//checking if employee exist in the company.
			
			else
				System.out.println("Employee does not exist"); 
		    }
		case 3->{
			
			//Removing employee from the database.
			int eid;
			System.out.print("Enter Employee Id:");
			eid = sc.nextInt();	
			
			
			int var4 = hrd.removeEmployee(eid);
			
			if (var4==1)
				System.out.println("Employee removed successfully.");
			//checking whether employee exist in the company or not.
			else
				System.out.println("Employee doesn't exist");	
		   }
	   }
		
		sc.close();  //Scanner object closed.

      }
}
