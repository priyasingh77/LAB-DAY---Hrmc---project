package com.HRMS;
import  java .sql.*;


public class HRMSdao {
		
			Connection con ;
			void connect() throws Exception{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection("jdbc:mysql://localhost:3306/singh","root","96432671");
			}
	
			int newEmployee(Employee obj)throws Exception{
				
				String query = "select * from employee where ePhone = ' " + obj.ephone + " ' ";
				Statement st = con.createStatement();
				ResultSet se = st.executeQuery(query);	
				
				if (se.next()) {
					return -1;
					
				}
				else {
					String query2 = ("INSERT into employee(ename,ephone,esal,elocation,edesignation) values(?,?,?,?,?);");
					
					PreparedStatement p = con.prepareStatement(query2);
					
					p.setString(1, obj.ename);				//Inserting employee to the database.
					p.setString(2, obj.ephone);
					p.setInt(3, obj.esal);
					p.setString(4, obj.elocation);
					p.setString(5, obj.edesignation);
					
					int count = p.executeUpdate();	
					return count;	
					
				}		
				
			}
			int removeEmployee(int eid ) throws Exception{
				 Statement ds =con.createStatement();
				 
				//executing query to fetch data
					ResultSet rs = ds.executeQuery("select * from employee where eid="+eid);
				 if (rs.next()) {
					 rs.close();
					 
					 Statement s = con.createStatement();
					 
					 //Deleting employee row from the table.
						int count = s.executeUpdate("DELETE from employee WHERE eid = "+eid);		
						return 1;
			     	 }
				 
				 else {
					 return 0;
				 }
			}
			
			public int increasesal(int eid,int hike) throws Exception{
				Statement st = con.createStatement();
				ResultSet rs =st.executeQuery("select * from employee where eid =\"+eid");
				
				if(rs.next()) {
			Statement s = con.createStatement();
			
			int count = s.executeUpdate("update employee set eSal=eSal+((eSal*" + hike + ")/100) where eid= "+ eid);
			return count;	
				}
				else {
					return 0;
				}
			}
			
	
			
	
}
	
		
